<?php
	class Config {
		public $dbhost = 'localhost';
		public $dbuser = 'scandiweb';
		public $dbpass = 'k1dbyBxNfNn(w1@8';
		public $dbname = 'scandiweb';
	}
?>